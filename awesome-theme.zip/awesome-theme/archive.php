<?php get_header() ; ?>
<!--START Section -->
<section>
  <div class="container">
    <div class="row">
     <div class="col-md-9 col-sm-8">
        <div class="blog-post-middle">
     <?php
			while ( have_posts() ) : the_post();

				get_template_part( 'template-parts/content', get_post_format() );

				// If comments are open or we have at least one comment, load up the comment template.
				if ( comments_open() || get_comments_number() ) :
					comments_template();
				endif;

			endwhile; // End of the loop.
			?>
</div>
</div>
<?php get_sidebar() ; ?>
    </div>
    <!-- end .row --> 
  </div>
</section>
<!--END MidSection --> 
<?php get_footer() ; ?>

// When the DOM is ready, run this function
$(document).ready(function() {
	
  //Set the carousel options
  $('#quote-carousel').carousel({
    pause: true,
    interval: 4000,
  });
});


$(document).ready(function() {
		
	//JS of OUR HAPPY CLIENTS
	$('.owl-carousel').owlCarousel({
        autoplay:true,
        loop:true,
	  	margin:15,
		responsiveClass:true,
		dots:true,
		responsive:{
			0:{
				items:2,
				nav:false
			},
			600:{
				items:4,
				nav:false
			},
			1000:{
				items:6,
				nav:false,
			},
			
		}
	});
});

<?php get_header() ;  ?>
<!--START Section -->
<section>
  <div class="container-fluid">
    <div class="row"> 
      <script type="text/javascript" src="http://maps.google.com/maps/api/js?sensor=false"></script>
      <div style="overflow:hidden;height:400px;width:100%;">
        <div id="gmap_canvas" style="height:400px;width:100%;"></div>
        <style>
#gmap_canvas img{max-width:none!important;background:none!important}
</style>
        <a class="google-map-code" href="http://www.staubsauger-test.biz" id="get-map-data">staubsauger test</a></div>
      <script type="text/javascript"> function init_map(){var myOptions = {zoom:14,center:new google.maps.LatLng(40.805478,-73.96522499999998),mapTypeId: google.maps.MapTypeId.ROADMAP};map = new google.maps.Map(document.getElementById("gmap_canvas"), myOptions);marker = new google.maps.Marker({map: map,position: new google.maps.LatLng(40.805478, -73.96522499999998)});infowindow = new google.maps.InfoWindow({content:"<b>The Breslin</b><br/>2880 Broadway<br/> New York" });google.maps.event.addListener(marker, "click", function(){infowindow.open(map,marker);});infowindow.open(map,marker);}google.maps.event.addDomListener(window, 'load', init_map);</script> 
    </div>
  </div>
  <!--  //  map  -->
  <div class="container">
    <div class="row">
      <div class="col-md-4 col-sm-4 contact">
        <div class="contact_left">
          <div class="single_contact">
            <div class="single_contact_icon"> <span class="fa fa-phone"></span> </div>
            <div class="single_contact_text">
              <h4>Phone</h4>
              <a href="tel:+923336983168">+92-999-888-777</a> <br>
              <a href="tel:+921112222333">+92-111-2222-333</a> </div>
          </div>
          <div class="single_contact">
            <div class="single_contact_icon"> <span class="fa fa-envelope-o"></span> </div>
            <div class="single_contact_text">
              <h4>Email</h4>
              <a href="mailto:info@awesomeone.com">info@scriptsbundle.com</a> <br>
              <a href="mailto:contact@awesomeone.com">contact@scriptsbundle.com</a> </div>
          </div>
          <div class="single_contact">
            <div class="single_contact_icon"> <span class="fa fa-map-marker"></span> </div>
            <div class="single_contact_text">
              <h4>Address</h4>
              <p>225 Street, Town road,<br>
                Bulding Market, Yoyu</p>
            </div>
          </div>
        </div>
      </div>
      <div class="col-md-8 col-sm-8">
        <div class="contact-form-container">
          <form method="post" id="contact-form">
            <div class="row clearfix">
              <div class="column col-md-6 col-sm-12 col-xs-12">
                <div class="form-group">
                  <input type="text" name="username" value="" placeholder="Username" required>
                </div>
                <div class="form-group">
                  <input type="email" name="email" value="" placeholder="Email" required>
                </div>
                <div class="form-group">
                  <input type="text" name="phone" value="" placeholder="Phone" required>
                </div>
              </div>
              <div class="column col-md-6 col-sm-12 col-xs-12">
                <div class="form-group">
                  <textarea name="message" placeholder="Your Message" required></textarea>
                </div>
              </div>
              <div class="col-md-12 col-xs-12">
                <div class="text-center">
                  <button type="submit" name="submit" class="btn btn-info">Send Message</button>
                </div>
              </div>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
</section>
<!--END MidSection --> 
<?php get_footer() ; ?>
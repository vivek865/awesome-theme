<?php  get_header() ; ?>
<!--START Section -->
<section>
<div class="container">
    <div class="row">
      <div class="col-md-12">
        <div class="not-found"> <a href="<?php echo home_url() ; ?>">404</a>
          <h3>Page Not Found</h3>
          <p><?php esc_html_e( 'Oops! That page can&rsquo;t be found.', 'awesome-theme' ); ?></p>
        </div>
        <!-- end .not-found --> 
        
      </div>
      <!-- end .col-md-12 --> 
    </div>
    <!-- end .row --> 
  </div>
</section>
<!--END MidSection --> 
<?php get_footer() ; ?>
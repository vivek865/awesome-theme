<?php
/**
 * awesome theme Theme Customizer.
 *
 * @package theme
 */

/**
 * Add postMessage support for site title and description for the Theme Customizer.
 *
 * @param WP_Customize_Manager $wp_customize Theme Customizer object.
 */
function theme_customize_register( $wp_customize ) {
	$wp_customize->get_setting( 'blogname' )->transport         = 'postMessage';
	$wp_customize->get_setting( 'blogdescription' )->transport  = 'postMessage';
	$wp_customize->get_setting( 'header_textcolor' )->transport = 'postMessage';
}
add_action( 'customize_register', 'theme_customize_register' );

/**
 * Binds JS handlers to make Theme Customizer preview reload changes asynchronously.
 */
function theme_customize_preview_js() {
	wp_enqueue_script( 'theme_customizer', get_template_directory_uri() . '/js/customizer.js', array( 'customize-preview' ), '20151215', true );
}
add_action( 'customize_preview_init', 'theme_customize_preview_js' );


Kirki::add_config( 'my_theme', array(
    'capability'    => 'edit_theme_options',
    'option_type'   => 'theme_mod',
) );
Kirki::add_panel( '1st_panel', array(
    'priority'    => 10,
    'title'       => __( 'HOME PAGE SETUP', 'textdomain' ),
    'description' => __( 'My Description', 'textdomain' ),
) );
Kirki::add_section( 'social_link', array(
	'title'      => esc_attr__( 'SOCIAL LINK', 'awesome-theme' ),
	 'panel'          => '1st_panel',
	'priority'   => 2,
	'capability' => 'edit_theme_options',
	'description' => esc_attr__( 'setup the social link for your website', 'awesome-theme' ),
) );
Kirki::add_field( 'facebook', array(
	'type'     => 'text',
	'settings' => 'facebook',
	'label'    => __( 'FACEBOOK URL ', 'awesome-theme' ),
	'description' => esc_attr__( 'setup the facebook link for your website', 'awesome-theme' ),
	'help' => esc_attr__( 'setup the facebook link for your website', 'awesome-theme' ),
	'section'  => 'social_link',
	'default'  => esc_attr__( 'https://facebook.com', 'awesome-theme' ),
	'priority' => 10,
) );
Kirki::add_field( 'twitter', array(
	'type'     => 'text',
	'settings' => 'twitter',
	'label'    => __( 'TWITTER_URL ', 'awesome-theme' ),
	'description' => esc_attr__( 'setup the twitter link for your website', 'awesome-theme' ),
	'help' => esc_attr__( 'setup the twitter link for your website', 'awesome-theme' ),
	'section'  => 'social_link',
	'default'  => esc_attr__( 'https://twitter.com', 'awesome-theme' ),

	'priority' => 10,
) );
Kirki::add_field( 'google', array(
	'type'     => 'text',
	'settings' => 'google',
	'label'    => __( 'G-PLUS_URL ', 'awesome-theme' ),
	'description' => esc_attr__( 'setup the twitter link for your website', 'awesome-theme' ),
	'help' => esc_attr__( 'setup the twitter link for your website', 'awesome-theme' ),
	'section'  => 'social_link',
	'default'  => esc_attr__( 'https://google.com', 'awesome-theme' ),
		'description' => esc_attr__( 'setup the google plus link for your website', 'awesome-theme' ),
	'priority' => 10,
) );
Kirki::add_field( 'contact_no', array(
	'type'     => 'text',
	'settings' => 'contact_no',
	'label'    => __( 'CONTACT NO', 'awesome-theme' ),
	'description' => esc_attr__( 'setup the CONTACT NO FOR your website', 'awesome-theme' ),
	'help' => esc_attr__( 'setup the CONTACT NO FOR your website', 'awesome-theme' ),
	'section'  => 'social_link',
	'default'  => esc_attr__( '1234567890', 'awesome-theme' ),
		'description' => esc_attr__( 'setup the google plus link for your website', 'awesome-theme' ),
	'priority' => 10,
) );
Kirki::add_section( 'slider', array(
	'title'      => esc_attr__( 'SLIDER', 'awesome-theme' ),
	 'panel'          => '1st_panel',
	'priority'   => 2,
	'capability' => 'edit_theme_options',
	'description' => esc_attr__( 'setup the social link for your website', 'awesome-theme' ),
) );

Kirki::add_field( 'my_config', array(
	'type'        => 'repeater',
	'label'       => esc_attr__( 'add slider', 'awesome-theme' ),
	'section'     => 'slider',
	'priority'    => 10,
	'settings'    => 'my_setting',
	'default'     => array(
		array(
			'link_text' => esc_attr__( 'Kirki Site', 'awesome-theme' ),
			'link_url'  => 'https://kirki.org',
		),
		array(
			'link_text' => esc_attr__( 'Kirki Repository', 'awesome-theme' ),
			'link_url'  => 'https://github.com/aristath/kirki',
		),
	),
	'fields' => array(
		'link_text' => array(
			'type'        => 'text',
			'label'       => esc_attr__( 'slider text', 'awesome-theme' ),
			'description' => esc_attr__( 'This will be the label for your link', 'awesome-theme' ),
			'default'     => '',
		),
		'link_sub_text' => array(
			'type'        => 'text',
			'label'       => esc_attr__( 'slider sub text', 'awesome-theme' ),
			'description' => esc_attr__( 'This will be the label for your link', 'awesome-theme' ),
			'default'     => '',
		),
		'button_text' => array(
			'type'        => 'text',
			'label'       => esc_attr__( 'call to action  text', 'awesome-theme' ),
			'description' => esc_attr__( 'This will be the label for your link', 'awesome-theme' ),
			'default'     => '',
		),
		'button_link' => array(
			'type'        => 'text',
			'label'       => esc_attr__( 'call to action  link', 'awesome-theme' ),
			'description' => esc_attr__( 'This will be the label for your link', 'awesome-theme' ),
			'default'     => '',
		),
		'link_url' => array(
	'type'        => 'image',
	'label'       => __( 'This is the label', 'awesome-theme' ),
	'description' => __( 'This is the control description', 'awesome-theme' ),
	'help'        => __( 'This is some extra help text.', 'awesome-theme' ),
	'default'     => '',
	
),
	)
) );
Kirki::add_section( 'welcome_note', array(
	'title'      => esc_attr__( 'WELCOME NOTE ', 'awesome-theme' ),
	 'panel'          => '1st_panel',
	'priority'   => 2,
	'capability' => 'edit_theme_options',
	'description' => esc_attr__( 'setup the social link for your website', 'awesome-theme' ),
) );
Kirki::add_field( 'title', array(
	'type'     => 'text',
	'settings' => 'title',
	'label'    => __( 'WELCOME NOTE TITLE ', 'awesome-theme' ),
	'description' => esc_attr__( 'setup the WELCOME NOTE TITLE ON HOME SCREEN for your website', 'awesome-theme' ),
	'help' => esc_attr__( 'setup the WELCOME NOTE TITLE ON HOME SCREEN for your website', 'awesome-theme' ),
	'section'  => 'welcome_note',
	'default'  => esc_attr__( 'WELCOME NOTE TITLE ON HOME SCREEN', 'awesome-theme' ),
		'description' => esc_attr__( 'setup the WELCOME NOTE TITLE for your website', 'awesome-theme' ),
	'priority' => 10,
) );
Kirki::add_field( 'discription', array(
	'type'     => 'textarea',
	'settings' => 'discription',
	'label'    => __( 'WELCOME NOTE DISCRIPTOIN ', 'awesome-theme' ),
	'description' => esc_attr__( 'setup the WELCOME NOTE DISCRIPTOIN for your website', 'awesome-theme' ),
	'help' => esc_attr__( 'setup the WELCOME NOTE DISCRIPTOIN for your website', 'awesome-theme' ),
	'section'  => 'welcome_note',
	'default'  => esc_attr__( 'WELCOME NOTE DISCRIPTOIN', 'awesome-theme' ),
		'description' => esc_attr__( 'setup the WELCOME NOTE DISCRIPTOIN for your website', 'awesome-theme' ),
	'priority' => 10,
) );
Kirki::add_field( 'wel_thumb', array(
	'type'        => 'image',
	'settings'    => 'wel_thumb',
	'label'       => __( 'WELCOME NOTE THUMBNAIL', 'awesome-theme' ),
	'description' => __( 'WELCOME NOTE THUMBNAIL SETUP', 'awesome-theme' ),
	'help'        => __( 'WELCOME NOTE THUMBNAIL SETUP.', 'awesome-theme' ),
	'section'     => 'welcome_note',
	'default'     => '',
	'priority'    => 10,
) );
Kirki::add_section( 'about_site', array(
	'title'      => esc_attr__( 'ABOUT SITE ', 'awesome-theme' ),
	 'panel'          => '1st_panel',
	'priority'   => 2,
	'capability' => 'edit_theme_options',
	'description' => esc_attr__( 'setup the social link for your website', 'awesome-theme' ),
) );
Kirki::add_field( 'about_site_sec', array(
	'type'        => 'repeater',
	'label'       => esc_attr__( 'ABOUT SITE SECTION ', 'awesome-theme' ),
	'section'     => 'about_site',
	'priority'    => 10,
	'settings'    => 'about_site_sec',
	'default'     => array(
		array(
			'link_text' => esc_attr__( 'Kirki Site', 'awesome-theme' ),
			'link_url'  => 'https://kirki.org',
		),
		array(
			'link_text' => esc_attr__( 'Kirki Repository', 'awesome-theme' ),
			'link_url'  => 'https://github.com/aristath/kirki',
		),
	),
	'fields' => array(
		'about_title' => array(
			'type'        => 'text',
			'label'       => esc_attr__( 'ABOUT TITLE', 'awesome-theme' ),
			'description' => esc_attr__( 'This will be the ABOUT TITLE ', 'awesome-theme' ),
			'default'     => '',
		),
		'about_disc' => array(
			'type'        => 'textarea',
			'label'       => esc_attr__( 'DISCRIPTION', 'awesome-theme' ),
			'description' => esc_attr__( 'This will be DISCRIPTION', 'awesome-theme' ),
			'default'     => '',
		),
   'about_icon' => array(
	'type'        => 'image',
	'label'       => __( 'icon', 'awesome-theme' ),
	'description' => __( 'set icon', 'awesome-theme' ),
	'help'        => __( 'set icon', 'awesome-theme' ),
	'default'     => '',
	
),
)
) );


Kirki::add_field( 'my_config', array(
	'type'        => 'repeater',
	'label'       => esc_attr__( 'Repeater Control', 'my_textdomain' ),
	'section'     => 'my_section',
	'priority'    => 10,
	'settings'    => 'my_setting',
	'default'     => array(
		array(
			'link_text' => esc_attr__( 'Kirki Site', 'my_textdomain' ),
			'link_url'  => 'https://kirki.org',
		),
		array(
			'link_text' => esc_attr__( 'Kirki Repository', 'my_textdomain' ),
			'link_url'  => 'https://github.com/aristath/kirki',
		),
	),
	'fields' => array(
		'link_text' => array(
			'type'        => 'text',
			'label'       => esc_attr__( 'Link Text', 'my_textdomain' ),
			'description' => esc_attr__( 'This will be the label for your link', 'my_textdomain' ),
			'default'     => '',
		),
		'link_url' => array(
			'type'        => 'text',
			'label'       => esc_attr__( 'Link URL', 'my_textdomain' ),
			'description' => esc_attr__( 'This will be the link URL', 'my_textdomain' ),
			'default'     => '',
		),
	)
) );
